#include "Game.h"

int main(int argc, char* args[]) {
    Game game;
    game.run();
    return 0;
}
