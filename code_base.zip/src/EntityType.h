//
// Created by capn on 8/29/25.
//
#pragma once

enum class EntityType {
    PLAYER,
    ENEMY,
    BLOCKER,
    GOOMBA // Examples for later
};